package com.Teacher.TeacherApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeacherAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeacherAppApplication.class, args);
	}

}
